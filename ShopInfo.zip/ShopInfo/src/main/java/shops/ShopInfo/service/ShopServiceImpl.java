package shops.ShopInfo.service;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import shops.ShopInfo.Constants;
import shops.ShopInfo.googleApi.AddressConverter;
import shops.ShopInfo.googleApi.model.GoogleResponse;
import shops.ShopInfo.googleApi.model.Location;
import shops.ShopInfo.googleApi.model.Result;
import shops.ShopInfo.model.ShopRequest;
import shops.ShopInfo.repository.ShopJpaRepository;

/**
 * @author Bhupinder Singh
 *
 */
@Service
public class ShopServiceImpl implements ShopService {

	@Autowired
	ShopJpaRepository shopJpaRepository;

	@Autowired
	AddressConverter addressConverter;

	/*
	 * This method will add request to h2 database with its lattitude and
	 * longitude
	 */
	@Transactional
	public ShopRequest addShopAddress(ShopRequest shopRequest) throws IOException {

		// String fullAddress = "Apollo Bunder2,Mumbai ,Maharashtra, India";
		String fullAddress = shopRequest.getShopNumber() + shopRequest.getShopName() + ","
				+ shopRequest.getShopAddresses() + "," + shopRequest.getPostCode() + "," + shopRequest.getCountry();
		GoogleResponse res = addressConverter.convertToLatLong(fullAddress);

		for (Result result : res.getResults()) {
			shopRequest.setLat(result.getGeometry().getLocation().getLat());
			shopRequest.setLng(result.getGeometry().getLocation().getLng());
		}
		shopJpaRepository.save(shopRequest);

		shopRequest.setStatus(Constants.STATUS);
		return shopRequest;
	}

	/*
	 * This method is to get all the saved shop addresses
	 */
	@Transactional
	public List<ShopRequest> getShopAddress() {
		List<ShopRequest> shopResponse = shopJpaRepository.findAll();
		return shopResponse;
	}

	/*
	 * This method will calculate the closest location from given already saved
	 * data according to provided lattitude an longtitude
	 */
	@Transactional
	public ShopRequest closestLocation(Location location) {

		float lat = Float.parseFloat(location.getLat());
		float lng = Float.parseFloat(location.getLng());

		List<ShopRequest> shopResponse = shopJpaRepository.findAll();

		Location locations = new Location();
		Map<Long, Location> locPair = new HashMap<Long, Location>();

		Map<Long, Float> minPair = new HashMap<Long, Float>();

		for (int i = 0; i < shopResponse.size(); i++) {
			locations.setLat(shopResponse.get(i).getLat());
			locations.setLng(shopResponse.get(i).getLng());
			locPair.put(shopResponse.get(i).getShopNumber(), locations);
		}

		for (Entry<Long, Location> entry : locPair.entrySet()) {

			float lat1 = Float.parseFloat(entry.getValue().getLat());
			float lng2 = Float.parseFloat(entry.getValue().getLng());

			minPair.put(entry.getKey(), distFrom(lat, lng, lat1, lng2));
		}

		Float a = Collections.min(minPair.values());

		for (Entry<Long, Float> entry : minPair.entrySet())
			if (entry.getValue().equals(a)) {
				ShopRequest shopRequest = shopJpaRepository.findByShopNumber(entry.getKey());
				return shopRequest;
			}
		return null;
	}

	/*
	 * This method is to calculate the distance between two lcoations
	 */
	private static float distFrom(float lat1, float lng1, float lat2, float lng2) {
		double earthRadius = 6371000; // meters
		double dLat = Math.toRadians(lat2 - lat1);
		double dLng = Math.toRadians(lng2 - lng1);
		double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat1))
				* Math.cos(Math.toRadians(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		float dist = (float) (earthRadius * c);

		return dist;
	}
}
