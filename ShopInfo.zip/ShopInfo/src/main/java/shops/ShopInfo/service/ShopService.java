package shops.ShopInfo.service;

import java.io.IOException;
import java.util.List;

import shops.ShopInfo.googleApi.model.Location;
import shops.ShopInfo.model.ShopRequest;

public interface ShopService {

	ShopRequest addShopAddress(ShopRequest shopRequest) throws IOException;

	List<ShopRequest> getShopAddress();

	ShopRequest closestLocation(Location location);
}
