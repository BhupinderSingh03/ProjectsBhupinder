package shops.ShopInfo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import shops.ShopInfo.model.ShopRequest;

/**
 * @author Bhupinder Singh
 *
 */
@Repository
public interface ShopJpaRepository extends JpaRepository<ShopRequest, String> {
	public ShopRequest findByShopNumber(Long shopNumber);
}
