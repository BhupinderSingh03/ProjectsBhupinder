package shops.ShopInfo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SHOP_ADDRESS")
public class ShopRequest {

	@Id
	@Column(name = "SHOP_NUMBER")
	private Long shopNumber;
	
	@Column(name = "SHOP_NAME")
	private String shopName;
	
	@Column(name = "POST_CODE")
	private String postCode;
	
	@Column(name = "SHOP_ADDRESSES")
	private String shopAddresses;

	private String status;
	
	@Column(name = "LAT")
	private String lat;

	@Column(name = "LNG")
	private String lng;
	
	@Column(name = "COUNTRY")
	private String country;
}
