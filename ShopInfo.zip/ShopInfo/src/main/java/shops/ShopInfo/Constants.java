package shops.ShopInfo;

public class Constants {

	public static final String URL = "http://maps.googleapis.com/maps/api/geocode/json";
	public static final String STATUS = "Successfully Saved";
}
