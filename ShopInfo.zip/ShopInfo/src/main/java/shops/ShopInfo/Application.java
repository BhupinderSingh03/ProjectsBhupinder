package shops.ShopInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author Bhupinder Singh
 *
 */
@SpringBootApplication
@Configuration
@ComponentScan(basePackages = { "shops.ShopInfo" })
@EnableTransactionManagement
@EnableJpaRepositories("shops.ShopInfo.repository")
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
