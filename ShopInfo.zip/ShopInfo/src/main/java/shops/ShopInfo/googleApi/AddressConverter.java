package shops.ShopInfo.googleApi;

import java.io.IOException;

import shops.ShopInfo.googleApi.model.GoogleResponse;

public interface AddressConverter {
	
	GoogleResponse convertToLatLong(String fullAddress) throws IOException;
}
