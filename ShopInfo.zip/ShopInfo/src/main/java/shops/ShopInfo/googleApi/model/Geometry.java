package shops.ShopInfo.googleApi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Geometry {

	private Location location;

	private String location_type;

	@JsonIgnore
	private Object bounds;

	@JsonIgnore

	private Object viewport;

}