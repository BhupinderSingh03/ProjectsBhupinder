package shops.ShopInfo.googleApi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Result {

	private String formatted_address;

	private boolean partial_match;

	private Geometry geometry;

	@JsonIgnore
	private Object address_components;

	@JsonIgnore
	private Object types;
	
	private String place_id;

}