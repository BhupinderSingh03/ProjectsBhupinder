package shops.ShopInfo.googleApi.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Location {

	private String lat;

	private String lng;
}