package shops.ShopInfo;

import static org.hamcrest.CoreMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import static org.mockito.Matchers.any;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;

import shops.ShopInfo.controller.ShopController;
import shops.ShopInfo.googleApi.model.Location;
import shops.ShopInfo.model.ShopRequest;
import shops.ShopInfo.service.ShopService;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class ShopControllerTest {

	@InjectMocks
	private ShopController ShopController;

	@Mock
	private ShopRequest shopRequest;
	
	@Mock
	private ShopService shopService;
	
	@Mock
	private Location location ;
	
	@Test
	public void testAdd() throws Exception {

		when(shopService.addShopAddress(shopRequest)).thenReturn(shopRequest);

		ShopController.add(shopRequest);

		verify(shopService, atLeastOnce()).addShopAddress(shopRequest);
	}
	
	@Test
	public void testFetch() throws Exception {

		List<ShopRequest> shopRequests  = new ArrayList<ShopRequest>();
		when(shopService.getShopAddress()).thenReturn(shopRequests);

		ShopController.fetch();

		verify(shopService, atLeastOnce()).getShopAddress();
	}
	
	@Test
	public void testFetchlntLng() throws Exception {

		when(shopService.closestLocation(location)).thenReturn(shopRequest);

		ShopController.fetchlntLng("122","232");

		verify(shopService, atLeastOnce()).closestLocation((Location) any());
	}
}
