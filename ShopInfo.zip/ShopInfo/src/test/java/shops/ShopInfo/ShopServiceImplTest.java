package shops.ShopInfo;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;

import shops.ShopInfo.googleApi.AddressConverter;
import shops.ShopInfo.googleApi.model.Geometry;
import shops.ShopInfo.googleApi.model.GoogleResponse;
import shops.ShopInfo.googleApi.model.Location;
import shops.ShopInfo.googleApi.model.Result;
import shops.ShopInfo.model.ShopRequest;
import shops.ShopInfo.repository.ShopJpaRepository;
import shops.ShopInfo.service.ShopServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class ShopServiceImplTest {

	@InjectMocks
	private ShopServiceImpl shopServiceImpl;

	@Mock
	private ShopJpaRepository shopJpaRepository;
	
	@Mock
	private ShopRequest shopRequest;
	

	@Mock
	private AddressConverter addressConverter;
	

	@Test
	public void testGetShopAddress() throws Exception {

		List<ShopRequest> shopResponse = new ArrayList<ShopRequest>();
		when(shopJpaRepository.findAll()).thenReturn(shopResponse);

		shopServiceImpl.getShopAddress();

		verify(shopJpaRepository, atLeastOnce()).findAll();
	}
	
	@Test(expected = Exception.class)
	public void testAddShopAddressNullValue() throws Exception {

		 ShopRequest shopRequests = new ShopRequest();
		 shopRequests.setCountry("India");
		 shopRequests.setPostCode("maharashtra 135001");
		 shopRequests.setShopName("sa");
		 shopRequests.setShopNumber((long) 2132);
		 shopRequests.setShopAddresses("pune");
		 
		 String fullAddress = shopRequest.getShopNumber() + shopRequest.getShopName() + ","
					+ shopRequest.getShopAddresses() + "," + shopRequest.getPostCode() + "," + shopRequest.getCountry();
		 
		 Result result =  new Result();
		 Geometry geometry = new Geometry();
		 Location location = new Location();
		 GoogleResponse res = new GoogleResponse();
		 
		 location.setLat("12321");
		 location.setLng("31231");
		 
		 geometry.setLocation(location);
		 result.setGeometry(geometry);
		 Result results[]= new Result[10];
		 
		 results[0]=result;
		 res.setResults(results);
			when(addressConverter.convertToLatLong(fullAddress)).thenReturn(res);
		when(shopJpaRepository.save(shopRequests)).thenReturn(shopRequests);
	
		
		shopServiceImpl.addShopAddress(shopRequests);

		verify(shopJpaRepository, atLeastOnce()).save(shopRequests);
	}
}

